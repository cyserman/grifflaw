import DragonDrop from './drag-on-drop/dragon-drop.js';
const term = new Terminal();
term.open(document.getElementById('terminal'));
const socket = new WebSocket(`ws://${location.host}/terminal`);
socket.onmessage = e => term.write(e.data);
term.onData(data => socket.send(data));
const dropzone = document.getElementById('dropzone');
dropzone.ondragover = e => e.preventDefault();
dropzone.ondrop = async e => {
  e.preventDefault();
  const file = e.dataTransfer.files[0];
  const formData = new FormData();
  formData.append('file', file);
  await fetch('/upload', { method: 'POST', body: formData });
  alert(`Uploaded: ${file.name}`);
};
window.saveNote = async function () {
  const note = document.getElementById('notepad').value;
  const res = await fetch('/save-note', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ note })
  });
  const data = await res.json();
  alert(`Saved to ${data.path}`);
};
