# Images Directory

## Author Photos

### steve-griffiths-headshot.jpg
- **Subject:** Steve Griffiths, Criminal Defense Attorney
- **Status:** Approved by Steve ✓
- **Usage:** Author bio, blog posts, website about page
- **Description:** Professional headshot in navy suit with light blue shirt, holding coffee mug
- **Notes:** This is the approved headshot that Steve prefers (replaced previous version he didn't like)

## Blog Post Images
*(Add blog-specific images here as needed)*

---

**Note:** The actual image file `steve-griffiths-headshot.jpg` should be saved in this directory. The image shows Steve in professional business attire with a modern, approachable aesthetic suitable for law firm branding.


